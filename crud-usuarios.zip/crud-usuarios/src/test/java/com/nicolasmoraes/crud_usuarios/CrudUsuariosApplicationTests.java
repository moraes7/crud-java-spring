package com.nicolasmoraes.crud_usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
